

cd 
mkdir .config
mkdir .config/fbpanel/

 cp -v  .fbpanelrc    ~/.config/fbpanel/default  
 cp -v  .blackboxrc     ~/.blackboxrc

 tar xvpfz images.tar.gz 
 cp -v -r images  ~/.config/fbpanel 


